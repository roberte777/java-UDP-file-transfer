# java-UDP-file-transfer
Group members: Cole Spencer, Ethan Wilkes

Our source files end in .java. The docker config files I used to simulate two machines are included. 

The res folder is the folder containing the resource that will be requested. The final folder contains the final resource AFTER the file transfer.

The client needs to be ran with TWO command line arguments, one decimal number for the percent for the packet corruption and one decimal number for the percent for the packet loss. 
